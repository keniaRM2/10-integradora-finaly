-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema sale
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema sale
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `sale` DEFAULT CHARACTER SET utf8 ;
USE `sale` ;

-- -----------------------------------------------------
-- Table `sale`.`rol`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sale`.`rol` (
  `id_rol` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`id_rol`),
  UNIQUE INDEX `usuario_UNIQUE` (`nombre` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sale`.`status`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sale`.`status` (
  `id_status` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`id_status`),
  UNIQUE INDEX `usuario_UNIQUE` (`nombre` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sale`.`genero`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sale`.`genero` (
  `id_genero` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`id_genero`),
  UNIQUE INDEX `usuario_UNIQUE` (`nombre` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sale`.`persona`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sale`.`persona` (
  `id_persona` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(100) NOT NULL,
  `primer_apellido` VARCHAR(100) NOT NULL,
  `segundo_apellido` VARCHAR(100) NULL,
  `fecha_nacimiento` DATE NOT NULL,
  `genero_id` INT NOT NULL,
  PRIMARY KEY (`id_persona`),
  INDEX `fk_persona_genero1_idx` (`genero_id` ASC) VISIBLE,
  CONSTRAINT `fk_persona_genero1`
    FOREIGN KEY (`genero_id`)
    REFERENCES `sale`.`genero` (`id_genero`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sale`.`usuario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sale`.`usuario` (
  `id_usuario` INT NOT NULL AUTO_INCREMENT,
  `usuario` VARCHAR(100) NOT NULL,
  `contrasena` VARCHAR(100) NOT NULL,
  `fecha_registro` DATETIME NOT NULL,
  `rol_id` INT NOT NULL,
  `status_id` INT NOT NULL,
  `persona_id` INT NULL,
  PRIMARY KEY (`id_usuario`),
  UNIQUE INDEX `usuario_UNIQUE` (`usuario` ASC) VISIBLE,
  INDEX `fk_usuario_rol_idx` (`rol_id` ASC) VISIBLE,
  INDEX `fk_usuario_status1_idx` (`status_id` ASC) VISIBLE,
  INDEX `fk_usuario_persona1_idx` (`persona_id` ASC) VISIBLE,
  UNIQUE INDEX `persona_id_UNIQUE` (`persona_id` ASC) VISIBLE,
  CONSTRAINT `fk_usuario_rol`
    FOREIGN KEY (`rol_id`)
    REFERENCES `sale`.`rol` (`id_rol`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_usuario_status1`
    FOREIGN KEY (`status_id`)
    REFERENCES `sale`.`status` (`id_status`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_usuario_persona1`
    FOREIGN KEY (`persona_id`)
    REFERENCES `sale`.`persona` (`id_persona`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sale`.`contacto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sale`.`contacto` (
  `id_contacto` INT NOT NULL AUTO_INCREMENT,
  `correo_electronico` VARCHAR(100) NOT NULL,
  `telefono_principal` VARCHAR(15) NOT NULL,
  `telefono_secundario` VARCHAR(15) NOT NULL,
  `persona_id` INT NOT NULL,
  PRIMARY KEY (`id_contacto`),
  INDEX `fk_contacto_persona1_idx` (`persona_id` ASC) VISIBLE,
  UNIQUE INDEX `persona_id_persona_UNIQUE` (`persona_id` ASC) VISIBLE,
  CONSTRAINT `fk_contacto_persona1`
    FOREIGN KEY (`persona_id`)
    REFERENCES `sale`.`persona` (`id_persona`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sale`.`direccion`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sale`.`direccion` (
  `id_direccion` INT NOT NULL AUTO_INCREMENT,
  `numero_interior` VARCHAR(5) NULL,
  `numero_exterior` VARCHAR(5) NOT NULL,
  `calle` VARCHAR(100) NOT NULL,
  `colonia` VARCHAR(100) NOT NULL,
  `municipio` VARCHAR(100) NOT NULL,
  `entidad_federativa` VARCHAR(100) NOT NULL,
  `persona_id` INT NOT NULL,
  PRIMARY KEY (`id_direccion`),
  INDEX `fk_direccion_persona1_idx` (`persona_id` ASC) VISIBLE,
  CONSTRAINT `fk_direccion_persona1`
    FOREIGN KEY (`persona_id`)
    REFERENCES `sale`.`persona` (`id_persona`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sale`.`color`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sale`.`color` (
  `id_color` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id_color`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sale`.`categoria`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sale`.`categoria` (
  `id_categoria` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(50) NOT NULL,
  `status_id` INT NOT NULL,
  PRIMARY KEY (`id_categoria`),
  UNIQUE INDEX `usuario_UNIQUE` (`nombre` ASC) VISIBLE,
  INDEX `fk_categoria_status1_idx` (`status_id` ASC) VISIBLE,
  CONSTRAINT `fk_categoria_status1`
    FOREIGN KEY (`status_id`)
    REFERENCES `sale`.`status` (`id_status`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sale`.`producto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sale`.`producto` (
  `id_producto` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(100) NOT NULL,
  `descripcion` TEXT NOT NULL,
  `precio` DOUBLE NOT NULL,
  `existencia` INT NOT NULL,
  `status_id` INT NOT NULL,
  `color_id` INT NOT NULL,
  `categoria_id` INT NOT NULL,
  PRIMARY KEY (`id_producto`),
  UNIQUE INDEX `usuario_UNIQUE` (`nombre` ASC) VISIBLE,
  INDEX `fk_producto_status1_idx` (`status_id` ASC) VISIBLE,
  INDEX `fk_producto_color1_idx` (`color_id` ASC) VISIBLE,
  INDEX `fk_producto_categoria1_idx` (`categoria_id` ASC) VISIBLE,
  CONSTRAINT `fk_producto_status1`
    FOREIGN KEY (`status_id`)
    REFERENCES `sale`.`status` (`id_status`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_producto_color1`
    FOREIGN KEY (`color_id`)
    REFERENCES `sale`.`color` (`id_color`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_producto_categoria1`
    FOREIGN KEY (`categoria_id`)
    REFERENCES `sale`.`categoria` (`id_categoria`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sale`.`imagen`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sale`.`imagen` (
  `id_imagen` INT NOT NULL AUTO_INCREMENT,
  `formato` VARCHAR(5) NOT NULL,
  `imagen` LONGBLOB NOT NULL,
  `producto_id` INT NOT NULL,
  PRIMARY KEY (`id_imagen`),
  INDEX `fk_imagen_producto1_idx` (`producto_id` ASC) VISIBLE,
  CONSTRAINT `fk_imagen_producto1`
    FOREIGN KEY (`producto_id`)
    REFERENCES `sale`.`producto` (`id_producto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sale`.`subcategoria`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sale`.`subcategoria` (
  `id_subcategoria` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(50) NOT NULL,
  `categoria_id` INT NOT NULL,
  `status_id` INT NOT NULL,
  PRIMARY KEY (`id_subcategoria`),
  UNIQUE INDEX `usuario_UNIQUE` (`nombre` ASC) INVISIBLE,
  UNIQUE INDEX `subcategoria_unique` (`nombre` ASC) VISIBLE,
  INDEX `fk_subcategoria_categoria1_idx` (`categoria_id` ASC) VISIBLE,
  INDEX `fk_subcategoria_status1_idx` (`status_id` ASC) VISIBLE,
  CONSTRAINT `fk_subcategoria_categoria1`
    FOREIGN KEY (`categoria_id`)
    REFERENCES `sale`.`categoria` (`id_categoria`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_subcategoria_status1`
    FOREIGN KEY (`status_id`)
    REFERENCES `sale`.`status` (`id_status`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sale`.`carrito`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sale`.`carrito` (
  `id_carrito` INT NOT NULL AUTO_INCREMENT,
  `fecha_actualizacion` DATETIME NOT NULL,
  `total` DOUBLE NOT NULL,
  `usuario_id` INT NOT NULL,
  PRIMARY KEY (`id_carrito`),
  INDEX `fk_carrito_usuario1_idx` (`usuario_id` ASC) VISIBLE,
  CONSTRAINT `fk_carrito_usuario1`
    FOREIGN KEY (`usuario_id`)
    REFERENCES `sale`.`usuario` (`id_usuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sale`.`carrito_producto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sale`.`carrito_producto` (
  `id_carrito_producto` INT NOT NULL AUTO_INCREMENT,
  `fecha_registro` DATETIME NOT NULL,
  `producto_id` INT NOT NULL,
  `carrito_id` INT NOT NULL,
  PRIMARY KEY (`id_carrito_producto`),
  INDEX `fk_carrito_copy1_producto1_idx` (`producto_id` ASC) VISIBLE,
  INDEX `fk_carrito_copy1_carrito1_idx` (`carrito_id` ASC) VISIBLE,
  UNIQUE INDEX `carrito_producto_unique` (`carrito_id` ASC, `producto_id` ASC) VISIBLE,
  CONSTRAINT `fk_carrito_copy1_producto1`
    FOREIGN KEY (`producto_id`)
    REFERENCES `sale`.`producto` (`id_producto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_carrito_copy1_carrito1`
    FOREIGN KEY (`carrito_id`)
    REFERENCES `sale`.`carrito` (`id_carrito`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sale`.`compra`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sale`.`compra` (
  `id_compra` INT NOT NULL AUTO_INCREMENT,
  `fecha_compra` DATETIME NOT NULL,
  `total` DOUBLE NOT NULL,
  `monto_pagado` DOUBLE NOT NULL,
  `persona_id` INT NOT NULL,
  `status_id` INT NOT NULL,
  PRIMARY KEY (`id_compra`),
  INDEX `fk_carrito_persona1_idx` (`persona_id` ASC) VISIBLE,
  UNIQUE INDEX `persona_id_UNIQUE` (`persona_id` ASC) VISIBLE,
  INDEX `fk_compra_status1_idx` (`status_id` ASC) VISIBLE,
  CONSTRAINT `fk_carrito_persona10`
    FOREIGN KEY (`persona_id`)
    REFERENCES `sale`.`persona` (`id_persona`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_compra_status1`
    FOREIGN KEY (`status_id`)
    REFERENCES `sale`.`status` (`id_status`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sale`.`compra_producto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sale`.`compra_producto` (
  `id_compra_producto` INT NOT NULL AUTO_INCREMENT,
  `cantidad` INT NOT NULL,
  `precio` DOUBLE NOT NULL,
  `total` DOUBLE NOT NULL,
  `comentario` VARCHAR(255) NULL,
  `producto_id` INT NOT NULL,
  `compra_id` INT NOT NULL,
  PRIMARY KEY (`id_compra_producto`),
  UNIQUE INDEX `usuario_UNIQUE` (`cantidad` ASC) VISIBLE,
  INDEX `fk_carrito_copy1_producto1_idx` (`producto_id` ASC) VISIBLE,
  UNIQUE INDEX `carrito_producto_unique` (`producto_id` ASC) VISIBLE,
  INDEX `fk_compra_producto_compra1_idx` (`compra_id` ASC) VISIBLE,
  CONSTRAINT `fk_carrito_copy1_producto10`
    FOREIGN KEY (`producto_id`)
    REFERENCES `sale`.`producto` (`id_producto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_compra_producto_compra1`
    FOREIGN KEY (`compra_id`)
    REFERENCES `sale`.`compra` (`id_compra`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sale`.`pago`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sale`.`pago` (
  `id_pago` INT NOT NULL AUTO_INCREMENT,
  `fecha_pago` DATETIME NOT NULL,
  `monto` DOUBLE NOT NULL,
  `persona_id` INT NOT NULL,
  `compra_id` INT NOT NULL,
  PRIMARY KEY (`id_pago`),
  INDEX `fk_carrito_persona1_idx` (`persona_id` ASC) VISIBLE,
  UNIQUE INDEX `persona_id_UNIQUE` (`persona_id` ASC) VISIBLE,
  INDEX `fk_pago_compra1_idx` (`compra_id` ASC) VISIBLE,
  CONSTRAINT `fk_carrito_persona100`
    FOREIGN KEY (`persona_id`)
    REFERENCES `sale`.`persona` (`id_persona`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_pago_compra1`
    FOREIGN KEY (`compra_id`)
    REFERENCES `sale`.`compra` (`id_compra`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sale`.`comprobante`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sale`.`comprobante` (
  `id_comprobante` INT NOT NULL AUTO_INCREMENT,
  `formato` VARCHAR(5) NOT NULL,
  `imagen` LONGBLOB NOT NULL,
  `pago_id` INT NOT NULL,
  PRIMARY KEY (`id_comprobante`),
  INDEX `fk_comprobante_pago1_idx` (`pago_id` ASC) VISIBLE,
  CONSTRAINT `fk_comprobante_pago1`
    FOREIGN KEY (`pago_id`)
    REFERENCES `sale`.`pago` (`id_pago`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sale`.`envio`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sale`.`envio` (
  `id_envio` INT NOT NULL AUTO_INCREMENT,
  `fecha_envio` DATETIME NOT NULL,
  `compra_id` INT NOT NULL,
  `persona_responsable_id` INT NOT NULL,
  PRIMARY KEY (`id_envio`),
  INDEX `fk_envio_compra1_idx` (`compra_id` ASC) VISIBLE,
  INDEX `fk_envio_persona1_idx` (`persona_responsable_id` ASC) VISIBLE,
  CONSTRAINT `fk_envio_compra1`
    FOREIGN KEY (`compra_id`)
    REFERENCES `sale`.`compra` (`id_compra`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_envio_persona1`
    FOREIGN KEY (`persona_responsable_id`)
    REFERENCES `sale`.`persona` (`id_persona`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
